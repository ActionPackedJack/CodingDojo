﻿using System;

namespace _1to255
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i=0; i<256; i++){
                 Console.WriteLine(i);
            }
           
        }
    }
}
